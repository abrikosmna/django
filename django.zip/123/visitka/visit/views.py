from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.


def main(request):
    return render(request, 'base.html', {})

def about_me(request):
    return render(request, 'about_me.html', {})

def project(request):
    return render(request, 'project.html', {})